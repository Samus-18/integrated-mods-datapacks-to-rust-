ThunderFusion JJThunder MAX - Horizon 26.3, Nightly aa27eca.
Overworld: min_y=-64, height=2096, logical_height=2096 (Y -64..2031).
Nether: min_y=0, height=2032, logical_height=128 (Y 0..2031).
Do not lower these; they are identical to supplied JJThunder packs.
Converted 33 original biomes, 32 placed features, 4 configured features, 4 carvers,
2 structures, 1 structure set, 1 block tag; retains 80 core density functions,
4 noise definitions and 2 material rules from the corrected 26.3 port.
Install ONE archive into a NEW TEST world, enable it, then test new chunks.
IMPORTANT: large height can cause extreme RAM/load times and game bugs.
No runtime test has been performed. Keep backups. Remove old ThunderFusion archives.
End remains unchanged. No Fabric binary code is included.
